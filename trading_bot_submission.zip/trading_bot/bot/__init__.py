"""Reusable trading bot components."""

